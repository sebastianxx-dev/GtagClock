﻿using BepInEx;
using UnityEngine;
using System;

[BepInPlugin("com.seb.GtagClock", "GtagClock", "1.0.0")]
public class TimeDisplayMod : BaseUnityPlugin
{
    private GUIStyle timeStyle;

    void OnGUI()
    {
        if (timeStyle == null)
        {
            timeStyle = new GUIStyle(GUI.skin.label);
            timeStyle.fontSize = 40;
            timeStyle.normal.textColor = Color.white;
            timeStyle.alignment = TextAnchor.UpperRight;
        }

        string currentTime = DateTime.Now.ToString("hh:mm tt");
        GUI.Label(new Rect(Screen.width - 250, 20, 230, 60), currentTime, timeStyle);
    }
}
